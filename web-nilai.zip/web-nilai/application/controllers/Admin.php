<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_controller{

  public function __construct()
  {
    parent::__construct();
    $this->load->database();
    $this->load->model('Admin_model');
    $this->load->model('Nilai_model');
    $this->load->library('form_validation');
    $this->load->helper(array('form','menu_helper','session'));
    $this->load->helper();
    
    if($this->session->userdata['state']){
      if($this->session->userdata['sesi']=='admin'){
        return true;
      }else if($this->session->userdata['sesi']=='guru'){
        redirect('guru');
      }else{
        redirect('siswa');
      }
    }else{
      redirect('login');
    }
  }

  public function logout()
  {
    $this->session->unset_userdata('login');
    $this->session->sess_destroy();
    redirect('login');
  }



  // =========================================
  // =========================================
  // =========================================
  //    CONTROLLER SISWA
  // =========================================
  // =========================================
  // =========================================

  public function index()
  {
    $status = $this->Admin_model->userStatus();
    $this->session->set_userdata('status', $status);

    $status = $this->session->userdata('status');
    
    $data['Judul'] = 'Daftar Siswa';
    $data['siswa'] = $this->Admin_model->dataSiswaIndex();
    $data['guru'] = $this->Admin_model->getDataGuru();
    $data['jumlahSiswa'] = $this->db->count_all('siswa');
    $data['jumlahGuru'] = $this->db->count_all('guru');
    $data['jumlahPelajaran'] = $this->db->count_all('mata_pelajaran');
    $data['jumlahKelas'] = $this->db->count_all('kelas');

    $this->load->view('templates/header', $data);
    $this->load->view('templates/menu-admin',$data);
    $this->load->view('admin/index', $data);
    $this->load->view('templates/footer');
  }

// ======================================================================
// ======================================================================

  public function daftar_siswa()
  {

    $data['Judul'] = 'Daftar Siswa';
    $data['siswa'] = $this->Admin_model->getDataSiswa();
    $data['guru'] = $this->Admin_model->getDataGuru();
    
    

    $this->load->view('templates/header', $data);
    $this->load->view('templates/menu-admin',$data);
    $this->load->view('admin/daftar-siswa', $data);
    $this->load->view('templates/footer');
  }


// ======================================================================
// ======================================================================
  public function tambah_siswa()
  {
    $data['Judul'] = 'Tambah Data Siswa';
    $data['kelas'] = $this->Admin_model->getDataKelas()->result_array();
    
      $this->form_validation->set_rules('no_siswa', 'No Id Siswa', 'required|trim');
      $this->form_validation->set_rules('nama_siswa', 'Nama Siswa', 'required|trim');
      $this->form_validation->set_rules('email', 'Email', 'required|valid_email');

      if ($this->form_validation->run() == FALSE) {
         $this->load->view('templates/header', $data);
         $this->load->view('templates/menu-admin', $data);
         $this->load->view('admin/tambah-siswa', $data);
         $this->load->view('templates/footer.php');
      }else{
        $config['upload_path'] = './public/images/user/siswa';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '256';
        $config['max_width'] = '1024';
        $config['max_width'] = '768';

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('foto')) {
          $errors = array('error' => $this->upload->display_errors());
          $post_image = 'unknown.png';
        }else{
          $data = array('upload_data' => $this->upload->data());
          $post_image = $this->upload->data('file_name');
        }
         $this->Admin_model->tambahDataSiswa($post_image);
         $this->session->set_flashdata('flash', 'Berhasil');
         redirect('admin/daftar-siswa');
      }
  }

  
// ======================================================================
// ======================================================================

  public function edit_siswa($id)
  {   
    $data['Judul'] = 'Edit Data Siswa';
    $data['siswa'] = $this->Admin_model->getSiswaById($id)->row_array();
    $data['kelas'] = $this->Admin_model->getDataKelas();

    $this->form_validation->set_rules('no_siswa', 'No Id Siswa', 'required');
    $this->form_validation->set_rules('nama_siswa', 'Nama Siswa', 'required');
    $this->form_validation->set_rules('email', 'Email', 'required|valid_email');

    if ($this->form_validation->run() == FALSE) {
       $this->load->view('templates/header', $data);
       $this->load->view('templates/menu-admin', $data);
       $this->load->view('admin/edit-siswa', $data);
       $this->load->view('templates/footer.php');
    }else{

      //simpan data sensitif di session
      $data = array(
        'id_siswa' => $data['siswa']['siswa_id'],
        'foto' => $data['siswa']['foto'],
        'status' => $data['siswa']['status']
      );
      $this->session->set_userdata($data);
        
      // upload foto
        $config['upload_path'] = './public/images/user/siswa';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '256';
        $config['max_width'] = '1024';
        $config['max_height'] = '768';

        $gambarStock = $this->session->userdata('foto');

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('foto')) {
          $errors = array('error' => $this->upload->display_errors());
          $post_image = $gambarStock;
        }else{
          if($gambarStock != 'unknown.png'){
            unlink(FCPATH . "public/images/user/siswa/" . $gambarStock );
          }
          $data = array('upload_data' => $this->upload->data());
          $post_image = $this->upload->data('file_name');
        }
       
      //simpan data ke db
       $this->Admin_model->ubahDataSiswa($post_image);
       $this->session->set_flashdata('flash', 'Berhasil');
       $this->session->unset_userdata($data);
       redirect('admin/daftar_siswa');
    }
  }


// ======================================================================
// ======================================================================
  public function detail_siswa($id)
  {
    $data['Judul'] = 'Detail Data Siswa';
    $data['siswa'] = $this->Admin_model->getSiswaById($id);

    $this->load->view('templates/header', $data);
    $this->load->view('templates/menu-admin',$data);
    $this->load->view('admin/detail-siswa', $data);
    $this->load->view('templates/footer.php');
  }
// ======================================================================
// ======================================================================


  public function daftar_kelas()
  {
    $data['Judul'] = 'Daftar Kelas';
    $data['kelas9'] = $this->db->get_where('kelas', ['no_kelas'=>'9'])->result_array();
    $data['kelas8'] = $this->db->get_where('kelas', ['no_kelas'=>'8'])->result_array();
    $data['kelas7'] = $this->db->get_where('kelas', ['no_kelas'=>'7'])->result_array();

    $this->form_validation->set_rules('nama_kelas', 'Nama Kelas', 'trim|required');
    $this->form_validation->set_rules('kode_kelas', 'Kode Kelas', 'trim|required');

    if ($this->form_validation->run() == FALSE) {
      $this->load->view('templates/header', $data);
      $this->load->view('templates/menu-admin');
      $this->load->view('admin/daftar-kelas');
      $this->load->view('templates/footer');
    }else{
      $no_kelas = $this->input->post('no_kelas', TRUE);
      $nama_kelas = $this->input->post('nama_kelas', TRUE);
      $kode_kelas = $this->input->post('kode_kelas', TRUE);

      $data = [
        'no_kelas' => $no_kelas,
        'nama_kelas' => $nama_kelas,
        'kode_kelas' => $kode_kelas
      ];

      $this->db->insert('kelas', $data);
      $this->session->set_flashdata(array('alert','Data Kelas Berhasil Ditambahkan','css'=>'alert-danger'));
      redirect('admin/daftar-kelas');
    }

  }



// ======================================================================
// ======================================================================

  public function hapusSiswa($id)
  {
    $this->Admin_model->hapusSiswaById($id);
    $this->session->set_flashdata('flash', 'Dihapus');
    redirect('admin/daftar-siswa');
  }




// ======================================================
// ======================================================
// ======================================================
// Controlller Nilai
// ======================================================
// ======================================================
// ======================================================  


public function daftar_nilai()
{

  $data['Judul'] = 'Daftar Nilai';
  $id_kelas = $this->input->get('kelas_sort');
  $data['id_nilai'] = $this->Nilai_model->getIdNilai();
  $data['nilai'] = $this->Nilai_model->getNilai();
  $data['kelas'] = $this->Admin_model->getDataKelas()->result_array();
  $data['matpel'] = $this->Nilai_model->getMatapelajaran();
  $data['sort'] = $this->input->post('kelas_sort');
  //$data['siswa'] = $this->Admin_model->getDataSiswa();
  
    $this->load->view('templates/header', $data);
    $this->load->view('templates/menu-admin');
    $this->load->view('admin/daftar-nilai',$data);
    $this->load->view('templates/footer');
  
}

public function getDataAjax()
{
  echo json_encode($this->Nilai_model->getNilaiById($_POST['id']));
}


public function getDataSiswaAjax()
{
  echo json_encode($this->Nilai_model->listEntitasSiswa());
}


public function getMatapelajaranAjax()
{
  echo json_encode($this->Nilai_model->listMataPelajaran());
}


public function getDataKelasAjax()
{
  echo json_encode($this->Nilai_model->listKelasSiswa());
}



public function updateNilaiHarian()
{
  $harian = array();
  $harian = $this->input->post();
  $implode = implode(',', $harian);
  $explode = explode(',', $implode);
  $id = array_shift($explode);
  $implode = implode(',', $explode);
  
  //var_dump($implode);
  $this->Nilai_model->ubah_nilai_harian($id, $implode);
  $this->session->set_flashdata('flash', 'Berhasil Dirubah');
  redirect('admin/daftar-nilai');
}



public function tambahDataNilai()
{
  $data = array();
  $data = $this->input->post();

  $kelas = $data['kelas'];
  $matpel = $data['matpel'];

  $this->Nilai_model->tambah_nilai_matpel($kelas, $matpel);
  $this->session->set_flashdata('flash', 'Nilai Siswa Berhasil Ditambah');
  redirect('admin/daftar-nilai');
}



// public function sort_nilai_siswa()
// {
//   $data_kelas = $this->input->post('kelas_sort');
//   $id_kelas = $data_kelas;
//   $this->Nilai_model->get_sort_nilai($limit, $offset, $id_kelas);
//   $this->session->set_flashdata('flash', 'Menampilkan Nilai Untuk Kelas '.$id_kelas);
//   redirect('admin/daftar-nilai');
// }






// ======================================================
// ======================================================
// ======================================================
// Controlller Guru
// ======================================================
// ======================================================
// ======================================================

public function daftar_guru()
{

  $data['Judul'] = 'Daftar Guru';
  $data['guru'] = $this->Admin_model->getDataGuru();
  

  $this->load->view('templates/header', $data);
  $this->load->view('templates/menu-admin',$data);
  $this->load->view('admin/daftar-guru', $data);
  $this->load->view('templates/footer');
}

// ======================================================================
// ======================================================================


public function tambah_guru()
{

  $data['Judul'] = 'Tambah Data Guru';
  
    $this->form_validation->set_rules('kd_guru', 'Kode Guru', 'required');
    $this->form_validation->set_rules('nama_guru', 'Nama Guru', 'required');
    $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
    $this->form_validation->set_rules('password', 'Password', 'required');
    $this->form_validation->set_rules('password_confirm', 'Confirm Password', 'required|matches[password]');

    if ($this->form_validation->run() == FALSE) {
       $this->load->view('templates/header', $data);
       $this->load->view('templates/menu-admin', $data);
       $this->load->view('admin/tambah-guru', $data);
       $this->load->view('templates/footer.php');
    }else{
      $config['upload_path'] = './public/images/user/guru';
      $config['allowed_types'] = 'gif|jpg|png';
      $config['max_size'] = '256';
      $config['max_width'] = '1024';
      $config['max_width'] = '768';
      $config['file_name'] = uniqid();

      $this->load->library('upload', $config);

      if (!$this->upload->do_upload('foto')) {
        $errors = array('error' => $this->upload->display_errors());
        $post_image = 'unknown.png';
      }else{
        $data = array('upload_data' => $this->upload->data());
        $post_image = $this->upload->data('file_name');
      }
       $this->Admin_model->tambahDataGuru($post_image);
       $this->session->set_flashdata('flash', 'Berhasil');
       redirect('admin/daftar-guru');
    }
}


// ======================================================================
// ======================================================================


public function edit_guru($id)
{   
  $data['Judul'] = 'Edit Data Guru';
  $data['guru'] = $this->Admin_model->getNamaGuru($id)->row_array();
  $data['mata_pelajaran'] = $this->Nilai_model->getMataPelajaran();
  

  $this->form_validation->set_rules('id_guru', 'Kode Guru', 'required');
  $this->form_validation->set_rules('nama_guru', 'Nama Guru', 'required');
  $this->form_validation->set_rules('email', 'Email', 'required|valid_email');

  if ($this->form_validation->run() == FALSE) {
     $this->load->view('templates/header', $data);
     $this->load->view('templates/menu-admin', $data);
     $this->load->view('admin/edit-guru', $data);
     $this->load->view('templates/footer.php');
  }else{
      //simpan data sensitif di session
      
      $data = array(
        'id_guru' => $data['guru']['guru_id'],
        'foto' => $data['guru']['foto'],
        'status' => $data['guru']['statuses']
      );
      $this->session->set_userdata($data);
      $config['upload_path'] = './public/images/user/guru';
      $config['allowed_types'] = 'gif|jpg|png';
      $config['max_size'] = '756';

      $gambarStock = $this->session->userdata('foto');

      $this->load->library('upload', $config);

      if (!$this->upload->do_upload('foto')) {
        $errors = array('error' => $this->upload->display_errors());
        $post_image = $gambarStock;
      }else{
        if($gambarStock != 'unknown.png'){
          unlink(FCPATH . "public/images/user/guru/" . $gambarStock );
        }
        $data = array('upload_data' => $this->upload->data());
        $post_image = $this->upload->data('file_name');
      }

     $this->Admin_model->ubahDataGuru($post_image);
     $this->session->unset_userdata($data);
     $this->session->set_flashdata(array('flash'=>'Data Guru Berhasil Diupdate','css'=>'alert-success'));
     redirect('admin/daftar_guru');
  }
}
}