<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Siswa extends CI_controller{

	public function __construct()
	{
		parent::__construct();
		
	    $this->load->database();
	    $this->load->model('Siswa_model');
	    $this->load->helper(array('url','form','menu_helper','session'));


		if($this->session->userdata['state']){
			if($this->session->userdata['sesi']=='siswa'){
			  return true;
			}else if($this->session->userdata['sesi']=='admin'){
			  redirect('admin');
			}else{
			  redirect('guru');
			}
		  }else{
			redirect('login');
		  }

	}


	public function index()
	{
		$data['Judul'] = 'Halaman Siswa';

		$this->load->view('templates/header', $data);
		$this->load->view('templates/menus-siswa');
		$this->load->view('siswa/index');
		$this->load->view('templates/footer');
	}


	public function logout()
  {
    $this->session->unset_userdata('login');
    $this->session->sess_destroy();
    redirect('login');
  }

}