<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_model extends CI_model{



   public function dataSiswaIndex()
   {
      $this->db->select('*');
      $this->db->from('siswa');
      $this->db->join('kelas', 'siswa.kode_kelas = kelas.kode_kelas', 'left');
      $this->db->order_by('nama_siswa', 'asc');
      $this->db->limit('5');
      $query = $this->db->get(); 
      return $query->result_array();
   }



   public function userStatus()
   {
      $this->db->select('*');
      $this->db->from('admin');
      $this->db->where('status', 'admin');
      $query = $this->db->get();
      return $query->row_array(); 
   }

   

   public function getDataSiswa()
   {
      $this->db->select('*');
      $this->db->from('siswa');
      $this->db->join('kelas', 'siswa.kode_kelas = kelas.kode_kelas', 'left');
      $this->db->order_by('nama_siswa', 'asc');
      return $query = $this->db->get()->result_array(); 
   }



   public function joinTableNilai()
   {
      $this->db->select('*');
      $this->db->from('nilai');
      $this->db->join('nilai_harian', 'nilai.nl_id = nilai_harian.nh_id', 'left');
      $this->db->join('nilai_tugas', 'nilai_harian.nh_id = nilai_tugas.nt_id', 'left');
      $this->db->join('nilai_mandiri', 'nilai_tugas.nt_id = nilai_mandiri.nm_id', 'left');
      $this->db->join('nilai_uts', 'nilai_mandiri.nm_id = nilai_uts.nut_id', 'left');
      $this->db->join('nilai_uas', 'nilai_uts.nut_id = nilai_uas.nua_id', 'left');
      $query = $this->db->get();
      return $query->result_array();
   }



   public function getSiswaById($id)
   {
      $this->db->select('*');
      $this->db->from('siswa');
      $this->db->join('kelas', 'siswa.kode_kelas = kelas.kode_kelas');
      $this->db->where(array('siswa_id' => $id));
      return $this->db->get();
   }



   public function getDataKelas()
   {
      $this->db->select('*');
      $this->db->from('kelas');
      $this->db->order_by('id_kelas', 'asc');
      return $query = $this->db->get();
   }



   public function hapusSiswaById($id)
   {
      $this->db->where('siswa_id', $id);
      $this->db->delete('siswa');
   }



   public function tambahDataSiswa($post_image)
   {
      $data = [
         "no_siswa" => $this->input->post('no_siswa', true),
         "nama_siswa" => ucfirst($this->input->post('nama_siswa', true)),
         "email" => $this->input->post('email', true),
         "kode_kelas" => $this->input->post('kode_kelas', true),
         "no_telepon" => $this->input->post('no_telepon', true),
         "foto" => $post_image,
         "status" => 'siswa'
      ];
      $this->db->insert('siswa', $data);
   }




   public function ubahDataSiswa($post_image)
   {
      $data = [
         "no_siswa" => $this->input->post('no_siswa', true),
         "nama_siswa" => ucfirst($this->input->post('nama_siswa', true)),
         "email" => $this->input->post('email', true),
         "no_telepon" => $this->input->post('no_telepon', true),
         "kode_kelas" => $this->input->post('kode_kelas', true),
         "foto" => $post_image
      ];

      $this->db->where('siswa_id', $this->session->userdata('id_siswa'));
      $this->db->update('siswa', $data);
   }








   public function getDataGuru()
   {
      $this->db->select('*');
      $this->db->from('guru');
      $this->db->join('mata_pelajaran', 'guru.matpel_id = mata_pelajaran.matpel_id', 'left');
      $query = $this->db->get(); 
      return $query->result_array();
   }

   public function ubahDataGuru($post_image)
   {
      $data = [
         "id_guru" => $this->input->post('id_guru', true),
         "nama_guru" => ucfirst($this->input->post('nama_guru', true)),
         "email" => $this->input->post('email', true),
         "matpel_id" => $this->input->post('mata_pelajaran', true),
         "foto" => $post_image
      ];

      $this->db->set($data);
      $this->db->where('guru_id', $this->session->userdata('id_guru'));
      $this->db->update('guru', $data);
   }

   public function getNamaGuru($id)
   {
      $this->db->select('*');
      $this->db->from('guru');
      $this->db->join('mata_pelajaran', 'guru.matpel_id = mata_pelajaran.matpel_id', 'left');
      $this->db->where('guru_id', $id);
      return $query = $this->db->get();   
   }





}