<?php

class Siswa_model extends CI_model{

	

}