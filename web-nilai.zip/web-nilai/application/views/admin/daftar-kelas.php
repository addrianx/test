<div class="content">
   <div class="container-fluid">
      <div class="row">


            <div class="col-md-12">
               
            <?php if (validation_errors()) : ?>
					<div class="alert alert-danger" role="alert">
						<?= validation_errors(); ?>
					</div>
				<?php endif; ?>

               <button type="button" class="btn btn-info" data-toggle="modal" data-target="#tambahKelasModal">
               Tambah Kelas Baru
               </button>

               <!-- Modal -->
               <div class="modal fade" id="tambahKelasModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
               <div class="modal-dialog modal-dialog-centered" role="document">
                  <div class="modal-content">
                     <div class="modal-header">
                     <h5 class="modal-title" id="exampleModalCenterTitle">Tambah Kelas Baru</h5>
                     <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                     </button>
                     </div>

                     <div class="modal-body">

                     <form action="" method="post">
                        <div class="form-group">
                           <div class="row">

                              <div class="col-5">
                                 <label for="no_kelas">Kelas</label>
                                 <select class="form-control" id="no_kelas" name="no_kelas">
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                    <option value="9">9</option>
                                 </select>
                              </div>

                              <div class="col-7">
                                 <label for="nama_kelas">Nama Kelas</label>
                                 <input type="text" class="form-control" name="nama_kelas" id="nama_kelas">
                              </div>

                              <div class="col-5">
                                 <label for="kode_kelas">Kode Kelas</label>
                                 <input type="text" class="form-control" name="kode_kelas" id="kode_kelas">
                              </div>

                           </div>
                        </div>

                     <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Tambah Kelas</button>
                     </div>
                        </form>
                     </div>
                  </div>
               </div>
               </div>


               <div class="card card-plain">
                  <div class="card-header card-header-primary">
                     <h4 class="card-title mt-0">Daftar Kelas</h4>
                     <p class="card-category"> Here is a subtitle for this table</p>
                  </div>

                  <div class="card-body mt-3 bg-white">
                     <div class="table-responsive">
                     <table class="table nowrap display compact" id="myTable">
                     <h4>Kelas 9</h4>
                     
                        <thead>
                           <tr>
                              <th>No</th>
                              <th>Kelas</th>
                              <th>Nama Kelas</th>
                              <th>Kode Kelas</th>
                              <th>Aksi</th>
                           </tr>
                        </thead>

                        <tbody>
                           <?php foreach($kelas9 as $kls9):?>
                           <?php $num=1;?>
                              <tr>
                                 <td><?=$num;?></td>
                                 <td><?=$kls9['no_kelas'];?></td>
                                 <td><?=$kls9['nama_kelas'];?></td>
                                 <td><?=$kls9['kode_kelas'];?></td>
                                 <td></td>
                              </tr>
                           <?php $num++;?>
                           <?php endforeach;?>
                        </tbody>
                        <tfoot>
                           <tr>
                              <th>No</th>
                              <th>Kelas</th>
                              <th>Nama Kelas</th>
                              <th>Kode Kelas</th>
                              <th>Aksi</th>
                           </tr>
                        </tfoot>
                     </table>
                     </div>
                  </div>  <!-- card-body -->


                  <div class="card-body mt-3 bg-white">
                     <div class="table-responsive">
                     <table class="table nowrap display compact" id="myTable2">
                     <h4>Kelas 8</h4>
                        <thead>
                           <tr>
                              <th>No</th>
                              <th>Kelas</th>
                              <th>Nama Kelas</th>
                              <th>Kode Kelas</th>
                              <th>Aksi</th>
                           </tr>
                        </thead>

                        <tbody>
                           <?php foreach($kelas8 as $kls8):?>
                           <?php $num=1;?>
                              <tr>
                                 <td><?=$num;?></td>
                                 <td><?=$kls8['no_kelas'];?></td>
                                 <td><?=$kls8['nama_kelas'];?></td>
                                 <td><?=$kls8['kode_kelas'];?></td>
                                 <td></td>
                              </tr>
                           <?php $num++;?>
                           <?php endforeach;?>
                        </tbody>
                        <tfoot>
                           <tr>
                              <th>No</th>
                              <th>Kelas</th>
                              <th>Nama Kelas</th>
                              <th>Kode Kelas</th>
                              <th>Aksi</th>
                           </tr>
                        </tfoot>
                     </table>
                     </div>
                     </div>

                     <div class="card-body mt-3 bg-white">
                        <div class="table-responsive">
                           <table class="table nowrap display compact" id="myTable3">
                           <h4>Kelas 7</h4>
                              <thead>
                                 <tr>
                                    <th>No</th>
                                    <th>Kelas</th>
                                    <th>Nama Kelas</th>
                                    <th>Kode Kelas</th>
                                    <th>Aksi</th>
                                 </tr>
                              </thead>

                              <tbody>
                                 <?php foreach($kelas7 as $kls7):?>
                                 <?php $num=1;?>
                                    <tr>
                                       <td><?=$num;?></td>
                                       <td><?=$kls7['no_kelas'];?></td>
                                       <td><?=$kls7['nama_kelas'];?></td>
                                       <td><?=$kls7['kode_kelas'];?></td>
                                       <td></td>
                                    </tr>
                                 <?php $num++;?>
                                 <?php endforeach;?>
                              </tbody>
                              <tfoot>
                                 <tr>
                                    <th>No</th>
                                    <th>Kelas</th>
                                    <th>Nama Kelas</th>
                                    <th>Kode Kelas</th>
                                    <th>Aksi</th>
                                 </tr>
                              </tfoot>
                           </table>
                        </div>
                     </div>

                  </div>  <!-- card-body -->


               </div> <!-- card card-plain -->

            </div>  <!-- col-md-12 -->
         </div>
      </div>
   </div>