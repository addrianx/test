<div class="content">
<div class="container-fluid">
   <div class="row">


<div class="col-12 col-lg-6">
   <a href="<?=base_url('admin/daftar-nilai/tambah-nilai');?>" class="btn btn-info tambah_modal" data-toggle="modal" data-target="#nilaiMdl">Tambah Kelas</a>
</div>

   <div class="col-12">
   
      <?php if($this->session->flashdata()==TRUE):?>
         <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong><?=$this->session->flashdata('flash');?> </strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
               <span aria-hidden="true">&times;</span>
            </button>
         </div>
      <?php endif;?>


      <div class="card">

         <div class="card-header card-header-primary">
            <h4 class="card-title mt-0"> Daftar Nilai Siswa</h4>
            <p class="card-category"> </p>
         </div>

              
         <div class="card-body">
			<div class="table-responsive" style="overflow-x: auto;">
				<table class="table table-hover nowrap display compact" id="myTable">
						<thead>
							<tr>
								<th>No</th>
								<th>Nama</th>
								<th>Kelas</th>
								<th>Mata Pelajaran</th>
								<th>Nilai Harian</th>
								<th>Nilai Tugas</th>
								<th>Nilai Mandiri</th>
								<th>Nilai UTS</th>
								<th>Nilai UAS</th>
								<th>Aksi</th>
							</tr>
						</thead>

						<tbody>
							<?php $num = 1; ?>
							<?php foreach( $id_nilai as $data ): ?>
								<tr class="datatable">
									<td><?=$num;?></td>
									<td><p><?= $data['nama_siswa']; ?></p></td>
									<td><p><?= $data['kode_kelas']; ?></p></td>
									<td><p><?= $data['nama_matpel']; ?></p></td>
									<td>
										<a href="<?= base_url() ;?>admin/daftar-nilai/edit-nilai/<?=$data['no_siswa']; ?>" class="btn btn-sm btn-info harian_modal" data-toggle="modal" data-target="#nilaiMdl" data-id="<?=$data['no_siswa']; ?>">Edit</a>
									</td>
									<td>
										<a href="<?= base_url() ;?>admin/daftar-nilai/edit-nilai/<?=$data['no_siswa']; ?>" class="btn btn-sm btn-info tugas_modal" data-toggle="modal" data-target="#nilaiMdl" data-id="<?=$data['no_siswa']; ?>">Edit</a>
									</td>
									<td>
										<a href="<?= base_url() ;?>admin/daftar-nilai/edit-nilai/<?=$data['no_siswa']; ?>" class="btn btn-sm btn-info mandiri_modal" data-toggle="modal" data-target="#nilaiMdl" data-id="<?=$data['no_siswa']; ?>">Edit</a>
									</td>
									<td>
										<a href="<?= base_url() ;?>admin/daftar-nilai/edit-nilai/<?=$data['no_siswa']; ?>" class="btn btn-sm btn-info uts_modal" data-toggle="modal" data-target="#nilaiMdl" data-id="<?=$data['no_siswa']; ?>">Edit</a>
									</td>
									<td>
										<a href="<?= base_url() ;?>admin/daftar-nilai/edit-nilai/<?=$data['no_siswa']; ?>" class="btn btn-sm btn-info uas_modal" data-toggle="modal" data-target="#nilaiMdl" data-id="<?=$data['no_siswa']; ?>">Edit</a>
									</td>
									<td>
										<a href="<?= base_url() ;?>admin/hapus_nilai_matpel/<?=$data['no_siswa']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Data Akan Hilang anda yakin ?');">Hapus</a>
									</td>
								</tr>
								<?php $num++; ?>
							<?php endforeach; ?>
						</tbody>
						<tfoot>
							<tr>
								<th>No</th>
								<th>Nama</th>
								<th>Kelas</th>
								<th>Mata Pelajaran</th>
								<th>Nilai Harian</th>
								<th>Nilai Tugas</th>
								<th>Nilai Mandiri</th>
								<th>Nilai UTS</th>
								<th>Nilai UAS</th>
								<th>Aksi</th>
							</tr>
						</tfoot>
               </table>

			 </div> <!--table-body -->

		</div> <!--card-body-->
		</div>
   </div>


      <div class="modal fade" id="nilaiMdl" tabindex="-1" role="dialog" aria-labelledby="nilaiModallabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable" role="document">
          <div class="modal-content">

            <div class="modal-header">
              <h5 class="modal-title" id="judul_modal">Nilai</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>

            <div class="modal-body">
					<form class="form" action="" method="post">
						<div class="row" id="col-nilai"></div> <!-- row -->	

						<div class="modal-footer">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
							<button type="submit" class="btn btn-primary btn-form">Simpan Nilai</button>
						</div> 
					</form>
            </div>
				
          </div>
        </div>
      </div>

      <div class="col-6 offset-3">
            <?php echo $this->pagination->create_links(); ?>
      </div>
   
      </div>
   </div>
</div>