<div class="content">
<div class="container-fluid">
   <div class="row">


   <div class="col-12 col-lg-6">
      <a href="<?= base_url() ;?>admin/daftar-siswa/tambah-siswa" class="btn btn-info">Tambah Siswa</a>
   </div>
   
      <div class="col-12">

         <?php if($this->session->flashdata()==TRUE):?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
               Data Siswa <strong><?=$this->session->flashdata('flash');?> </strong> Ditambahkan
               <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
               </button>
            </div>
         <?php endif;?>

         <div class="card">
            <div class="card-header card-header-primary">
               <h4 class="card-title mt-0"> Daftar Murid</h4>
               <p class="card-category"> </p>
            </div>

               <div class="card-body">
                  <div class="table-responsive" style="overflow-x: auto;">
                     <table class="table table-hover nowrap compact display" id="myTable">
                        <thead>
                           <tr>
                              <th>ID</th>
                              <th>Gambar</th>
                              <th>Nama</th>
                              <th>Kelas</th>
                              <th>Aksi</th>
                           </tr>
                        </thead>

                        <tbody>
                           <?php $num = 1; ?>
                           <?php foreach( $siswa as $data ): ?>
                              <tr>
                                 <td><?=$num;?></td>
                                 <td><img src="<?= base_url() ;?>public/images/user/siswa/<?=$data['foto'];?>" width="60" height="60" alt=""></td>
                                 <td><a href="<?= base_url() ;?>admin/daftar-siswa/detail-siswa/<?= $data['siswa_id']; ?>"><?= $data['nama_siswa']; ?></a></td>
											
                                 <td><a href=""><?= $data['no_kelas'].' - '.$data['nama_kelas']; ?></a></td>
											
                                 <td>
                                    <a href="<?= base_url() ;?>admin/daftar-siswa/edit-siswa/<?= $data['siswa_id']; ?>" class="btn btn-info">Edit</a>
                                    <a href="<?= base_url() ;?>admin/hapusSiswa/<?= $data['siswa_id']; ?>" class="btn btn-danger" onclick="return confirm('Data Akan Hilang anda yakin ?');">Hapus</a>
                                 </td>
                              </tr>
                              <?php $num++; ?>
                           <?php endforeach; ?>
                        </tbody>

                        <tfoot>
                           <tr>
                              <th>ID</th>
                              <th>Gambar</th>
                              <th>Nama</th>
                              <th>Kelas</th>
                              <th>Aksi</th>
                           </tr>
                        </tfoot>
                     </table>
                  </div>
               </div>
            </div>
         </div>

         <div class="col-6 offset-3">
            <?php echo $this->pagination->create_links(); ?>
         </div>

      </div>
   </div>
</div>