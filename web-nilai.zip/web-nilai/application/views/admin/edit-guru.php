<div class="content">
	<div class="container-fluid">
		<div class="row justify-content-center">
			<div class="col-12 col-md-10 col-md-offset-1">
			
				<form action="<?=base_url('admin/edit_guru/'.$guru['guru_id']);?>" method="post" enctype="multipart/form-data">
					
					<input type="hidden" name="id" value="<?=$guru['guru_id'];?>">
					<input type="hidden" name="gambarLama" value="<?=$guru['foto'];?>">
					<input type="hidden" name="statuses" value="<?=$guru['statuses'];?>">
					
					<div class="row">

						<div class="col-12 col-lg-8">
							<div class="form-group">
								<label for="nama_guru" class=""><b>Nama Guru</b></label>
								<input type="text" class="form-control" value="<?=$guru['nama_guru'];?>" name="nama_guru" id="nama_guru">
							</div>
						</div>

						<div class="col-12 col-lg-8">
							<div class="form-group">
								<label for="id_guru" class=""><b>Kode Guru</b></label>
								<input type="text" name="id_guru" id="if_guru" value="<?= $guru['id_guru']; ?>" class="form-control">
							</div>
						</div>

						<div class="col-12 col-lg-8">
							<div class="form-group">
								<label for="mata_pelajaran" class=""><b>Mata Pelajaran</b></label>
								<select class="form-control" name="mata_pelajaran" id="mata_pelajaran">
								<?php foreach($mata_pelajaran as $matpel) : ?>
									<option value="<?= $matpel['matpel_id']; ?>"><?= $matpel['nama_matpel']; ?></option>
								<?php endforeach;?>
								</select>
							</div>
						</div>

						<div class="col-12 col-lg-8">
							<div class="form-group">
								<label for="email" class=""><b>Email Guru</b></label>
								<input type="email" class="form-control" value="<?=$guru['email'];?>" name="email" id="email">
							</div>
						</div>

						<div class="col-12">
							<img src="<?=base_url();?>images/user/<?=$guru['foto'];?>" width="50" height="50" alt=""class="d-block">
							<input type="file" name="foto" id="foto">
						</div>

						<div class="col-12 col-lg-8 form-group">
							<label for="status">Status Akun</label>
							<input type="text" name="status" id="status" value="<?=$guru['statuses'];?>" class="form-control" readonly>
						</div>

					</div>

					<button type="submit" class="btn btn-lg btn-primary">Edit Data</button>

				</form>
			</div>
		</div>
	</div>
</div>