
<div class="content">
	<div class="container-fluid">
		<div class="row justify-content-center">
			<div class="col-10 col-lg-8">
			
				<?php if (validation_errors()) : ?>
					<div class="alert alert-danger" role="alert">
						<?= validation_errors(); ?>
					</div>
				<?php endif; ?>

					
				<?php echo form_open_multipart('admin/edit_siswa/'.$siswa['siswa_id']);?>
						
				<div class="form-group">
					<label for="no_siswa" class="">No Siswa</label>
					<input type="text" class="form-control" name="no_siswa" value="<?=$siswa['no_siswa'];?>" id="no_siswa">
				</div>
							
				<div class="form-group">
					<label for="nama_siswa" class="">Nama Siswa</label>
					<input type="text" class="form-control" name="nama_siswa" value="<?=$siswa['nama_siswa'];?>" id="nama_siswa">
				</div>
							
				 <div class="form-group">
				     <label for="email" class="">Email</label>
				     <input type="email" class="form-control" name="email" value="<?=$siswa['email'];?>" id="email" autocomplete="off">
				 </div>

				<div class="form-group">
					<label for="no_telepon" class="">No kontak/HP Siswa</label>
					<input type="text" class="form-control" name="no_telepon" value="<?=$siswa['no_telepon'];?>" id="no_telepon">
				</div>

				  	<label for="foto">Upload Foto</label><br>
				  	<img src="<?=base_url();?>public/images/user/siswa/<?=$siswa['foto'];?>" width="50" height="50" alt="">
				  	<input type="file" value="" name="foto" id="foto">


				<div class="form-group">
					<label for="kode_kelas" class="">No.ID Kelas</label>
					<input type="text" class="form-control" name="kode_kelas" value="<?=$siswa['kode_kelas'];?>" id="kode_kelas">
				</div>

				<div class="form-group">
					<label for="status">Status Akun</label>
					<select id="status" name="status" class="form-control" disabled>
					<option><?=$siswa['status'];?></option>
					</select>
				</div>

			  		<button type="submit" class="btn btn-lg btn-primary">Update Siswa</button>
				</form>
			</div>
		</div>
	</div>
</div>

