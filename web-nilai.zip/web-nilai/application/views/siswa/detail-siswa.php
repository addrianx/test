<div class="content">

   <div class="container-fluid">
      <div class="row">

         <div class="col-12">

            <div class="card card-profile">
               <div class="card-avatar">
                  <img src="../images/user/" alt="" class="img">
               </div>

               <div class="card-body">
                  <h4 class="card-title"></h4>
               </div>
             </div> <!--card card-profile -->

         </div>

      </div>
   </div>

</div>