<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-6 col-md-12">
        <div class="card">
          <div class="card-header card-header-danger">
            <a href="daftar-siswa.php"><h4 class="card-title"><i class="fa fa-user-o"></i> Daftar Nilai</h4></a>
            <p class="card-category">Daftar Nilai Semester 1 - Tahun Ajaran 2018/2019</p>
          </div>

          <div class="card-body table-responsive" width="100%">
            <table class="table table-hover">
              <thead class="text-warning">
                <th>No</th>
                <th>Mata Ajar</th>
                <th>Detail Nilai</th>
              </thead>

              <tbody>
                <tr>
                  <td><?php var_dump($this->session->userdata());?></td>
                  <td></td>
                  <td></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="col-lg-6 col-md-12">
        <div class="card">
          <div class="card-header card-header-primary ">
            <a href="daftar-siswa.php"><h4 class="card-title"><i class="fa fa-graduation-cap"></i> Daftar Tugas</h4></a>
            <p class="card-category">Tugas Siswa Kelas 9-Alexandria</p>
          </div>
          <div class="card-body table-responsive">


            <table class="table table-hover">
              <thead class="text-warning">
                <th>ID</th>
                <th>Foto</th>
                <th>Nama</th>
                <th>Kelas</th>
                <th>Jenis Kelamin</th>
              </thead>
              <tbody>

                <tr>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>
