<!--   Core JS Files   -->

<script src="<?= base_url().'public/vendor/js/core/popper.min.js'; ?>" type="text/javascript"></script>
<script src="<?= base_url().'public/vendor/js/core/bootstrap-material-design.min.js'; ?>" type="text/javascript"></script>
<script src="<?= base_url().'public/vendor/js/plugins/perfect-scrollbar.jquery.min.js'; ?>"></script>
<!--  Google Maps Plugin    -->
<!-- <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script> -->
<!-- Chartist JS -->
<script src="<?= base_url().'public/vendor/js/plugins/chartist.min.js' ;?>"></script>
<!--  Notifications Plugin    -->
<script src="<?= base_url().'public/vendor/js/plugins/bootstrap-notify.js' ;?>"></script>
<!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
<script src="<?= base_url().'public/vendor/js/material-dashboard.min.js?v=2.1.0' ;?>" type="text/javascript"></script>
<!-- Material Dashboard DEMO methods, don't include it in your project! -->
<script src="<?= base_url().'public/vendor/demo/demo.js' ;?>"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script> 
<script type="text/javascript" src="<?= base_url().'public/js/my-script.js';?>"></script>
<script>
   $(document).ready( function () {
      $('#myTable').DataTable();
      $('#myTable2').DataTable();
      $('#myTable3').DataTable();
   } );
</script>
</body>
</html>
