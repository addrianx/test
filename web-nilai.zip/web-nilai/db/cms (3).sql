-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 12, 2019 at 07:44 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(10) NOT NULL,
  `nama_admin` varchar(255) NOT NULL,
  `email` varchar(150) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `kontak_admin` varchar(255) NOT NULL,
  `status` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `nama_admin`, `email`, `pass`, `kontak_admin`, `status`) VALUES
(1, 'administrator', 'adipatrianugraha@outlook.com', 'admin1234', '081214493741', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `biodata_siswa`
--

CREATE TABLE `biodata_siswa` (
  `id_biodata` int(11) NOT NULL,
  `no_siswa` varchar(8) NOT NULL,
  `tempat_lahir` text NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `jenis_kelamin` varchar(9) NOT NULL,
  `agama` varchar(20) NOT NULL,
  `golongan_darah` varchar(20) NOT NULL,
  `nama_ayah` varchar(50) NOT NULL,
  `nama_ibu` varchar(50) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `biodata_siswa`
--

INSERT INTO `biodata_siswa` (`id_biodata`, `no_siswa`, `tempat_lahir`, `tanggal_lahir`, `jenis_kelamin`, `agama`, `golongan_darah`, `nama_ayah`, `nama_ibu`, `alamat`) VALUES
(33, '090101', 'Garut', '2012-03-06', 'Laki-laki', 'Islam', 'A', 'Indra ramadan s', 'Nita indriani', 'Garut kota'),
(34, '090102', 'Garut', '2005-01-12', 'Laki-laki', 'Islam', 'A', 'John Doe', 'Jane Doe', 'Garut'),
(35, '090103', '', '1970-01-01', 'Perempuan', 'Islam', 'A', 'Rudi', 'Tuti', 'Garkot'),
(36, '090104', '', '0000-00-00', 'perempuan', 'islam', '', '', '', ''),
(37, '090105', 'Garut', '2000-02-02', 'Perempuan', 'Islam', 'A', 'John doe', 'Jane doe', 'Garut'),
(38, '090106', '', '0000-00-00', 'perempuan', 'islam', '', '', '', ''),
(39, '090107', '', '0000-00-00', 'laki-laki', 'islam', '', '', '', ''),
(40, '090108', '', '0000-00-00', 'laki-laki', 'islam', 'A', '', '', ''),
(41, '090109', '', '0000-00-00', 'perempuan', 'islam', '', '', '', ''),
(42, '090110', '', '0000-00-00', 'laki-laki', 'islam', '', '', '', ''),
(43, '090111', '', '0000-00-00', 'laki-laki', 'islam', '', '', '', ''),
(44, '090112', '', '0000-00-00', 'laki-laki', 'islam', 'A', '', '', ''),
(45, '090113', 'Garut', '2000-08-23', 'Perempuan', 'Islam', 'A', 'Rukman', 'Ticeu', 'Bayongbong'),
(46, '090114', '', '0000-00-00', 'laki-laki', 'islam', 'A', '', '', ''),
(47, '090115', '', '2005-06-15', 'laki-laki', 'islam', 'N/A', 'John Doe', 'Jane Doe', 'Garut'),
(48, '090116', '', '1970-01-01', 'laki-laki', 'islam', 'A', '', '', ''),
(49, '090117', 'Garut', '2005-02-03', 'Laki-laki', 'Islam', 'A', '', '', 'Sukadana'),
(50, '090118', 'Garut', '2005-02-09', 'Laki-laki', 'Islam', 'A', '', '', ''),
(51, '090119', '', '0000-00-00', '', '', '', '', '', ''),
(52, '090120', '', '0000-00-00', '', '', '', '', '', ''),
(53, '090121', '', '0000-00-00', '', '', '', '', '', ''),
(54, '090122', '', '0000-00-00', '', '', '', '', '', ''),
(55, '090123', '', '0000-00-00', '', '', '', '', '', ''),
(56, '090124', '', '0000-00-00', '', '', '', '', '', ''),
(57, '090125', '', '0000-00-00', '', '', '', '', '', ''),
(58, '090126', '', '2004-01-08', '', '', '', '', '', ''),
(59, '090127', '', '0000-00-00', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `data_nilai`
--

CREATE TABLE `data_nilai` (
  `id_data_nilai` int(4) NOT NULL,
  `harian` varchar(100) NOT NULL,
  `tugas` varchar(100) NOT NULL,
  `mandiri` varchar(255) NOT NULL,
  `uts` varchar(5) NOT NULL,
  `uas` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `guru`
--

CREATE TABLE `guru` (
  `guru_id` int(255) NOT NULL,
  `matpel_id` int(6) NOT NULL,
  `id_guru` varchar(6) NOT NULL,
  `nama_guru` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `statuses` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `guru`
--

INSERT INTO `guru` (`guru_id`, `matpel_id`, `id_guru`, `nama_guru`, `pass`, `email`, `foto`, `statuses`) VALUES
(1, 1, '001', 'Ticeu Kustilawati S.Pd', 'nadil123', 'ticeukustilawati@outlook.com', 'guru.png', 'guru'),
(2, 1, '002', 'Reza Rahardian S.Pd', 'cikuraytiis', 'rezarahardian@gmail.com', 'gurus111.png', 'guru'),
(3, 1, '003', 'Katy Huber S.Pd', 'nightly234', 'katyhub@outlook.com', 'guru1.png', 'guru'),
(4, 1, '004', 'Helin Markham M.Pd', 'nightly234', 'katyhub@outlook.com', '5b73147ad21a6.png', 'guru'),
(7, 1, '006', 'Justus Depari', 'maslahat', 'justus.depari@gmail.com', 'gurus1111.png', 'guru');

-- --------------------------------------------------------

--
-- Table structure for table `kelas`
--

CREATE TABLE `kelas` (
  `id_kelas` int(11) NOT NULL,
  `nama_kelas` varchar(50) NOT NULL,
  `no_kelas` varchar(2) NOT NULL,
  `kode_kelas` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kelas`
--

INSERT INTO `kelas` (`id_kelas`, `nama_kelas`, `no_kelas`, `kode_kelas`) VALUES
(1, 'Amanda', '8', '0801'),
(2, 'Alexandria', '9', '0901'),
(3, 'Archimedes', '7', '0701');

-- --------------------------------------------------------

--
-- Table structure for table `mata_pelajaran`
--

CREATE TABLE `mata_pelajaran` (
  `matpel_id` int(6) NOT NULL,
  `nama_matpel` varchar(100) NOT NULL,
  `id_matpel` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mata_pelajaran`
--

INSERT INTO `mata_pelajaran` (`matpel_id`, `nama_matpel`, `id_matpel`) VALUES
(1, 'Biologi', 'MPBIO'),
(2, 'Fisika', 'MPFIS'),
(3, 'Kimia', 'MPKIM'),
(4, 'Bahasa Indonesia', 'MPIND');

-- --------------------------------------------------------

--
-- Table structure for table `nilai`
--

CREATE TABLE `nilai` (
  `nl_id` int(255) NOT NULL,
  `matpel_id` int(255) NOT NULL,
  `no_siswa` varchar(11) NOT NULL,
  `kode_kelas` varchar(4) NOT NULL,
  `kode_guru` varchar(100) NOT NULL,
  `harian` varchar(255) NOT NULL,
  `tugas` varchar(255) NOT NULL,
  `mandiri` varchar(255) NOT NULL,
  `uts` varchar(255) NOT NULL,
  `uas` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nilai`
--

INSERT INTO `nilai` (`nl_id`, `matpel_id`, `no_siswa`, `kode_kelas`, `kode_guru`, `harian`, `tugas`, `mandiri`, `uts`, `uas`) VALUES
(34, 1, '090101', '0901', '', '83,75,72,80,76,89,50', '78,67,67,80,76,89', '78,67,67,80,76', '79', '80'),
(35, 1, '090102', '0901', '', '78,67,67,80,76,89,80', '70,75,87,69,80,78', '78,67,67,80,76', '70', '90'),
(40, 1, '090103', '0901', '', '79,76', '', '', '', ''),
(41, 1, '090104', '0901', '', '', '', '', '', ''),
(42, 1, '090105', '0901', '', '', '', '', '', ''),
(43, 1, '090106', '0901', '', '', '', '', '', ''),
(44, 1, '090107', '0901', '', '', '', '', '', ''),
(45, 1, '090108', '0901', '', '', '', '', '', ''),
(46, 1, '090109', '0901', '', '', '', '', '', ''),
(47, 1, '090110', '0901', '', '', '', '', '', ''),
(48, 1, '090111', '0901', '', '', '', '', '', ''),
(49, 1, '090112', '', '', '', '', '', '', ''),
(50, 1, '090113', '', '', '', '', '', '', ''),
(51, 1, '090114', '', '', '', '', '', '', ''),
(52, 1, '090115', '', '', '', '', '', '', ''),
(53, 1, '090116', '', '', '', '', '', '', ''),
(54, 1, '090117', '', '', '', '', '', '', ''),
(55, 0, '090118', '', '', '', '', '', '', ''),
(56, 0, '090119', '', '', '', '', '', '', ''),
(57, 0, '090120', '', '', '', '', '', '', ''),
(58, 0, '090121', '', '', '', '', '', '', ''),
(59, 0, '090122', '', '', '', '', '', '', ''),
(60, 0, '090123', '', '', '', '', '', '', ''),
(61, 0, '090124', '', '', '', '', '', '', ''),
(62, 0, '090125', '', '', '', '', '', '', ''),
(63, 0, '090126', '', '', '', '', '', '', ''),
(64, 0, '090127', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id_post` int(5) NOT NULL,
  `id_user` int(11) NOT NULL,
  `title` varchar(140) NOT NULL,
  `content` varchar(20000) NOT NULL,
  `date_posts` datetime(6) NOT NULL,
  `thumb_post` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id_post`, `id_user`, `title`, `content`, `date_posts`, `thumb_post`) VALUES
(1, 1, 'How To Make an awesome bootstrap theme for beginner to', '&lt;h1&gt;&lt;strong&gt;Lorem ipsum dolor sit amet&lt;/strong&gt;&lt;/h1&gt;\r\n\r\n&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipisicing elit. Unde, nulla molestiae harum repellat, quasi, laboriosam est fugit accusantium, consequatur reiciendis voluptatum natus amet. Sint rerum, ratione tenetur pariatur a hic eum, repudiandae omnis error aliquid tempore commodi illum quod fugiat perferendis libero, ipsam animi eligendi minus quae impedit! Distinctio molestiae earum, nobis eos excepturi magnam optio rerum beatae enim blanditiis voluptates minima nemo asperiores ea officia mollitia similique illum autem sed aut ullam laborum eaque ad quaerat quam! Neque, perferendis.&lt;/p&gt;\r\n\r\n&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipisicing elit. Unde, nulla molestiae harum repellat, quasi, laboriosam est fugit accusantium, consequatur reiciendis voluptatum natus amet. Sint rerum, ratione tenetur pariatur a hic eum, repudiandae omnis error aliquid tempore commodi illum quod fugiat perferendis libero, ipsam animi eligendi minus quae impedit! Distinctio molestiae earum, nobis eos excepturi magnam optio rerum beatae enim blanditiis voluptates minima nemo asperiores ea officia mollitia similique illum autem sed aut ullam laborum eaque ad quaerat quam! Neque, perferendis.&lt;/p&gt;\r\n\r\n&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipisicing elit. Unde, nulla molestiae harum repellat, quasi, laboriosam est fugit accusantium, consequatur reiciendis voluptatum natus amet. Sint rerum, ratione tenetur pariatur a hic eum, repudiandae omnis error aliquid tempore commodi illum quod fugiat perferendis libero, ipsam animi eligendi minus quae impedit! Distinctio molestiae earum, nobis eos excepturi magnam optio rerum beatae enim blanditiis voluptates minima nemo asperiores ea officia mollitia similique illum autem sed aut ullam laborum eaque ad quaerat quam! Neque, perferendis.&lt;/p&gt;\r\n', '2018-07-31 12:56:22.000000', ''),
(2, 1, 'Tutorial PHP Programing Languange', '&lt;h1&gt;&lt;strong&gt;Lorem ipsum dolor sit amet&lt;/strong&gt;&lt;/h1&gt;\r\n\r\n&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipisicing elit. Unde, nulla molestiae harum repellat, quasi, laboriosam est fugit accusantium, consequatur reiciendis voluptatum natus amet. Sint rerum, ratione tenetur pariatur a hic eum, repudiandae omnis error aliquid tempore commodi illum quod fugiat perferendis libero, ipsam animi eligendi minus quae impedit! Distinctio molestiae earum, nobis eos excepturi magnam optio rerum beatae enim blanditiis voluptates minima nemo asperiores ea officia mollitia similique illum autem sed aut ullam laborum eaque ad quaerat quam! Neque, perferendis.&lt;/p&gt;\r\n\r\n&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipisicing elit. Unde, nulla molestiae harum repellat, quasi, laboriosam est fugit accusantium, consequatur reiciendis voluptatum natus amet. Sint rerum, ratione tenetur pariatur a hic eum, repudiandae omnis error aliquid tempore commodi illum quod fugiat perferendis libero, ipsam animi eligendi minus quae impedit! Distinctio molestiae earum, nobis eos excepturi magnam optio rerum beatae enim blanditiis voluptates minima nemo asperiores ea officia mollitia similique illum autem sed aut ullam laborum eaque ad quaerat quam! Neque, perferendis.&lt;/p&gt;\r\n\r\n&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipisicing elit. Unde, nulla molestiae harum repellat, quasi, laboriosam est fugit accusantium, consequatur reiciendis voluptatum natus amet. Sint rerum, ratione tenetur pariatur a hic eum, repudiandae omnis error aliquid tempore commodi illum quod fugiat perferendis libero, ipsam animi eligendi minus quae impedit! Distinctio molestiae earum, nobis eos excepturi magnam optio rerum beatae enim blanditiis voluptates minima nemo asperiores ea officia mollitia similique illum autem sed aut ullam laborum eaque ad quaerat quam! Neque, perferendis.&lt;/p&gt;\r\n', '2018-07-31 12:56:22.000000', ''),
(4, 2, 'Designing latest material design website in 2018', '&lt;p&gt;Berubah karena artikel&lt;/p&gt;\r\n', '2018-07-31 12:57:22.000000', ''),
(5, 1, 'Angular 2 or AngularJS ?', '', '2018-07-31 13:04:08.000000', ''),
(6, 2, 'Write a Js framework with VueJs', '', '2018-07-31 13:04:28.000000', ''),
(8, 3, 'Admin Theme For Full Stack Developer', '', '2018-07-31 13:05:06.000000', ''),
(9, 5, 'Are you ready for Firebird developer summit in Amsterdam', '', '2018-07-31 13:06:09.000000', ''),
(10, 5, 'Jquery 3.1.2 Updated Add it to your bower components', '', '2018-07-31 13:06:09.000000', ''),
(13, 6, 'ini judul 13', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Impedit quibusdam nisi, velit magnam deleniti itaque quam totam rem reiciendis, consequuntur amet perferendis ad, quidem repellat ullam quod non labore a eaque eveniet optio expedita.<br />\r\n&nbsp;</p>\r\n', '2018-07-25 00:00:00.000000', ''),
(14, 0, 'Site Management percobaan 12', '&lt;p&gt;&lt;strong&gt;nulis bro&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;br /&gt;\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit. Unde, nulla molestiae harum repellat, quasi, laboriosam est fugit accusantium, consequatur reiciendis voluptatum natus amet. Sint rerum, ratione tenetur pariatur a hic eum, repudiandae omnis error aliquid tempore commodi illum quod fugiat perferendis libero, ipsam animi eligendi minus quae impedit! Distinctio molestiae earum, nobis eos excepturi magnam optio rerum beatae enim blanditiis voluptates minima nemo asperiores ea officia mollitia similique illum autem sed aut ullam laborum eaque ad quaerat quam! Neque, perferendis.&lt;/p&gt;\r\n', '0000-00-00 00:00:00.000000', '');

-- --------------------------------------------------------

--
-- Table structure for table `siswa`
--

CREATE TABLE `siswa` (
  `siswa_id` int(255) NOT NULL,
  `no_siswa` varchar(15) NOT NULL,
  `nama_siswa` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `kode_kelas` varchar(4) NOT NULL,
  `no_telepon` varchar(25) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `siswa`
--

INSERT INTO `siswa` (`siswa_id`, `no_siswa`, `nama_siswa`, `email`, `pass`, `kode_kelas`, `no_telepon`, `foto`, `status`) VALUES
(1, '090101', 'Abdu Fattah Hidayatullah', 'abdufattah@gmail.com', '1234', '0901', '08123456789', 'Avatar (2).png', 'siswa'),
(2, '090102', 'Akmal Syafa Khairullah', 'mail@mail.com', '1234', '0901', '08123456789', '5c5951a1f0022.png', 'siswa'),
(3, '090103', 'Amelia Alfi Fauziyah', 'mail@mail.com', '$2y$10$uwYx0QLt7.KbJlJynDvjJOk6CMHvL3sDhvMJo1v4bmxL6ejInUvvy', '0901', '081214493741', '5c4ee7489d6c4.png', 'siswa'),
(4, '090104', 'Ammara Bratandari\r\n', '', '', '0901', '', 'Avatar (1).png', 'siswa'),
(5, '090105', 'Annida Larisa Asysyafa', 'annida@gmail.com', '', '0901', '09812312', '5c5951c95066d.png', 'siswa'),
(6, '090106', 'Aulya Larashanda Hanyfan\r\n', '', '', '0901', '', 'Avatar (1).png', 'siswa'),
(7, '090107', 'Faraz Haratul Maknun\r\n', '', '', '0901', '', 'Avatar (2).png', 'siswa'),
(8, '090108', 'Fatiyah Nurul Hidayah', '', '', '0901', '', 'Avatar (1).png', 'siswa'),
(9, '090109', 'Fidela Faizatul Adilah\r\n', '', '', '0901', '', 'Avatar (2).png', 'siswa'),
(10, '090110', 'Hasyir Sukma Dwi Nugraha', 'email@contoh.com', '', '0901', '0812000000', 'Avatar (2).png', 'siswa'),
(11, '090111', 'Ilham Tajul Arifin\r\n', '', '', '0901', '', 'Avatar (2).png', 'siswa'),
(12, '090112', 'Krista Dira Rizky', '', '', '0901', '', '5c4ed1bf7f117.png', 'siswa'),
(13, '090113', 'Lutfi Riyadul Basyari', 'mail@mail.com', '', '0901', '', '5c6e41cdc5ee2.png', 'siswa'),
(14, '090114', 'Mekhran Az Zulfan', '', '', '0901', '', '5c4ed26d25b22.png', 'siswa'),
(15, '090115', 'Mohammad Rizki Fauziansyah', 'mail@mail.com', '', '0901', '081214493741', '5c4f193d42f5f.png', 'siswa'),
(16, '090116', 'Muhammad Abdi Jaya Nagara', '', '', '0901', '', '5c50231e18836.png', 'siswa'),
(17, '090117', 'Muhammad Afkar Shahbaz', 'mail@mail.com', '', '0901', '', '5c59a1ca9d799.png', 'siswa'),
(18, '090118', 'Muhammad Aqil Rabbani', 'mail@mail.com', '', '0901', '', '5c6e41a1a79c9.png', 'siswa'),
(19, '090119', 'Muhammad Qaishar Fathin', 'qaishar.fathin@gmail.com', '', '0901', '0812000000', 'Avatar_(2)31.png', 'siswa'),
(20, '090120', 'Nasywa Haura Firmansyah', 'naswa.haura@gmail.com', '', '0901', '0812000000', '5c59a1bcc16a01.png', 'siswa'),
(21, '090121', 'Putri Alifia Fauzia', 'putri.alifia.fauzi@gmail.com', '', '0901', '0812000000', '', 'siswa'),
(22, '090122', 'Rahmi Rabbani\r\n', '', '', '0901', '', '', 'siswa'),
(23, '090123', 'Rangga Azyan\r\n', '', '', '0901', '', '', 'siswa'),
(24, '090124', 'Rida Millah Hanifah\r\n', '', '', '0901', '', '', 'siswa'),
(25, '090125', 'Syahra Fauziyah\r\n', '', '', '0901', '', '', 'siswa'),
(26, '090126', 'Tiara Aurelia Audina\r\n', '', '', '0901', '', '', 'siswa'),
(27, '090127', 'Venus Zalianti\r\n', '', '', '0901', '', '', 'siswa'),
(28, '0801001', 'Aldi Nugraha', 'aldi.nugraha@gmail.com', '', '0801', '0812000000', 'Avatar_(2)312.png', 'siswa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `biodata_siswa`
--
ALTER TABLE `biodata_siswa`
  ADD PRIMARY KEY (`id_biodata`),
  ADD UNIQUE KEY `no_siswa` (`no_siswa`);

--
-- Indexes for table `data_nilai`
--
ALTER TABLE `data_nilai`
  ADD PRIMARY KEY (`id_data_nilai`);

--
-- Indexes for table `guru`
--
ALTER TABLE `guru`
  ADD PRIMARY KEY (`guru_id`);

--
-- Indexes for table `kelas`
--
ALTER TABLE `kelas`
  ADD PRIMARY KEY (`id_kelas`),
  ADD UNIQUE KEY `kode_kelas` (`kode_kelas`);

--
-- Indexes for table `mata_pelajaran`
--
ALTER TABLE `mata_pelajaran`
  ADD PRIMARY KEY (`matpel_id`),
  ADD UNIQUE KEY `id_matpel` (`id_matpel`);

--
-- Indexes for table `nilai`
--
ALTER TABLE `nilai`
  ADD PRIMARY KEY (`nl_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id_post`);

--
-- Indexes for table `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`siswa_id`),
  ADD UNIQUE KEY `no_siswa` (`no_siswa`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `biodata_siswa`
--
ALTER TABLE `biodata_siswa`
  MODIFY `id_biodata` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `data_nilai`
--
ALTER TABLE `data_nilai`
  MODIFY `id_data_nilai` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `guru`
--
ALTER TABLE `guru`
  MODIFY `guru_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `kelas`
--
ALTER TABLE `kelas`
  MODIFY `id_kelas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `mata_pelajaran`
--
ALTER TABLE `mata_pelajaran`
  MODIFY `matpel_id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `nilai`
--
ALTER TABLE `nilai`
  MODIFY `nl_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id_post` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `siswa`
--
ALTER TABLE `siswa`
  MODIFY `siswa_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
