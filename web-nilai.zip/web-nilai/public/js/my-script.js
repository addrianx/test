$(document).ready(function() {

// Javascript method's body can be found in assets/js/demos.js
md.initDashboardPageCharts();

$("div").removeClass("bmd-form-group");





// Tambah Siswa Dan Nilai
// ======================
$('.tambah_modal').on('click', function(){
    $('.col-input').remove();
    $('div').remove('#btn')
    $('.modal-title').html('Tambah Data Nilai Siswa');
    $('.modal-body .form').attr('action', 'http://localhost/web-nilai/admin/tambahDataNilai');

    $('#col-nilai').append('<div class="col-12 col-input"><div class="form-group"><label for="daftar_kelas">Pilih Kelas Siswa</label><select class="form-control" id="daftar_kelas" name="kelas"></select></div></div>');

    $('#col-nilai').append('<div class="col-12 col-input"><div class="form-group"><label for="mata_pel">Pilih Mata Pelajaran</label><select class="form-control" id="mata_pel" name="matpel"></select></div></div>');    
 

    $.ajax({
        url :'http://localhost/web-nilai/admin/getDataKelasAjax',
        method : 'post',
        dataType : 'json',
        success : function(kelas){
   
            kelas.forEach(function(value, index){
                $('#daftar_kelas').append('<option value='+value.id_kelas+'>'+value.no_kelas+'</option>')
            })          
        } 
    });


    $.ajax({
            url : 'http://localhost/web-nilai/admin/getMatapelajaranAjax',
            method: 'post',
            dataType: 'json',
            success: function(matpel){

            matpel.forEach(function(value, index){
                $('#mata_pel').append('<option value='+value.id_matpel+'>'+value.nama_matpel+'</option>')
            })
                
        }
    });
});




// Edit Nilai Harian
// ============================================
// ============================================
// ============================================
$('.harian_modal').on('click', function(){
    $('.col-input').remove();
    $('div').remove('#btn')
    $('.modal-title').html('Nilai Harian Siswa');
    $('.modal-body .form').attr('action', 'http://localhost/web-nilai/admin/updateNilaiHarian');
    $('.modal-body').prepend('<div class="col-12" id="btn"><button class="btn btn-success" id="btn-tambah">Tambah Nilai</button></div>');
    
    $('#btn-tambah').click(function(){
        $('#col-nilai').append('<div class="col-6 col-input"><div class="form-group"><label for="nilai_baru">Nilai Harian baru</label><input class="form-control" id="nilai_baru" name="harian" value="" type="number"></div></div>');
    })

    const id = $(this).data('id');
    
    $.ajax({
        url :'http://localhost/web-nilai/admin/getDataAjax',
        data : {id, id},
        method : 'post',
        dataType : 'json',
        success : function(data){
            console.log(data.no_siswa);
            let myNilai = (data.harian);
            let myArray = myNilai.split(",");
            let dataLength = myArray.length;

            $('#col-nilai').append('<div class="col-12 col-input"><input class="form-control" id="no_siswa" name="no_siswa" type="hidden"></div>')
            $('#no_siswa').val(data.no_siswa);

            myArray.forEach(function(value, index) {
                index_number = index+1;
                let input = $('#col-nilai').append('<div class="col-6 col-input"><div class="form-group"><label for="nilai_'+index_number+'">Nilai Harian '+index_number+'</label><input class="form-control" id="nilai_'+index_number+'" name="harian'+index_number+'" value="'+value+'" type="number"></div></div>');  
                $('#nilai_'+index_number).val(value);

                
            });
            
        }
    });
});




// Edit Nilai tugas
// ============================================
// ============================================
// ============================================
$('.tugas_modal').on('click', function(){
    $('.col-input').remove();
    $('div').remove('#btn')
    $('.modal-title').html('Nilai Tugas Siswa');
    $('.modal-body').prepend('<div class="col-12" id="btn"><button class="btn btn-success" id="btn-tambah">Tambah Nilai</button></div>');
    $('.modal-body .form').attr('action', 'http://localhost/web-nilai/admin/updateNilaiTugas');
    const id = $(this).data('id');
    
    $.ajax({
        url :'http://localhost/web-nilai/admin/getDataAjax',
        data : {id, id},
        method : 'post',
        dataType : 'json',
        success : function(data){
            let myNilai = (data.tugas);
            let myArray = myNilai.split(",");
            let dataLength = myArray.length;

            myArray.forEach(function(value, index) {
                index_number = index+1;
                let input = $('#col-nilai').append('<div class="col-6 col-input"><div class="form-group"><label for="nilai_'+index_number+'">Nilai Tugas '+index_number+'</label><input class="form-control" id="nilai_'+index_number+'" type="number"></div></div>');  
                $('#nilai_'+index_number).val(value);
            });

        }
    });
});




// Edit Nilai Mandiri
// ============================================
// ============================================
// ============================================
$('.mandiri_modal').on('click', function(){
    $('.col-input').remove();
    $('div').remove('#btn');
    $('.modal-body').prepend('<div class="col-12" id="btn"><button class="btn btn-success" id="btn-tambah">Tambah Nilai</button></div>');
    $('.modal-title').html('Nilai Mandiri Siswa');
    const id = $(this).data('id');
    
    $.ajax({
        url :'http://localhost/web-nilai/admin/getDataAjax',
        data : {id, id},
        method : 'post',
        dataType : 'json',
        success : function(data){
            let myNilai = (data.mandiri);
            let myArray = myNilai.split(",");
            let dataLength = myArray.length;

            myArray.forEach(function(value, index) {
                index_number = index+1;
                let input = $('#col-nilai').append('<div class="col-6 col-input"><div class="form-group"><label for="nilai_'+index_number+'">Nilai Mandiri '+index_number+'</label><input class="form-control" id="nilai_'+index_number+'" type="number"></div></div>');  
                $('#nilai_'+index_number).val(value);
            });

        }
    });
});



// Edit Nilai uts
// ============================================
// ============================================
// ============================================
$('.uts_modal').one('click', function(){
    $('.col-input').remove();
    $('div').remove('#btn')
    $('.modal-body').prepend('<div class="col-12" id="btn"><button class="btn btn-success" id="btn-tambah">Tambah Nilai</button></div>');
    $('.modal-title').html('Nilai UTS Siswa');
    const id = $(this).data('id');
    
    $.ajax({
        url :'http://localhost/web-nilai/admin/getDataAjax',
        data : {id, id},
        method : 'post',
        dataType : 'json',
        success : function(data){
            let myNilai = (data.uts);
            let myArray = myNilai.split(",");
            let dataLength = myArray.length;

            myArray.forEach(function(value, index) {
                index_number = index+1;
                let input = $('#col-nilai').append('<div class="col-6 col-input"><div class="form-group"><label for="nilai_'+index_number+'">Nilai UTS '+index_number+'</label><input class="form-control" id="nilai_'+index_number+'" type="number"></div></div>');  
                $('#nilai_'+index_number).val(value);
            });

        }
    });
    
});




// Edit Nilai uas
// ============================================
// ============================================
// ============================================
$('.uas_modal').one('click', function(){
    $('.col-input').remove();
    $('div').remove('#btn')
    $('.modal-body').prepend('<div class="col-12" id="btn"><button class="btn btn-success" id="btn-tambah">Tambah Nilai</button></div>');
    $('.modal-title').html('Nilai UAS Siswa');
    const id = $(this).data('id');
    
    $.ajax({
        url :'http://localhost/web-nilai/admin/getDataAjax',
        data : {id, id},
        method : 'post',
        dataType : 'json',
        success : function(data){
            let myNilai = (data.uas);
            let myArray = myNilai.split(",");
            let dataLength = myArray.length;

            myArray.forEach(function(value, index) {
                index_number = index+1;
                let input = $('#col-nilai').append('<div class="col-6 col-input"><div class="form-group"><label for="nilai_'+index_number+'">Nilai UAS '+index_number+'</label><input class="form-control" id="nilai_'+index_number+'" type="number"></div></div>');  
                $('#nilai_'+index_number).val(value);
            });

        }
    });
        
});





// =============================================
// =============================================

$('#sortkelas').change(function(){
    // ambil ajax response
    $.ajax({
        type: "post",
        url: "<?= base_url("+admin/urut_nilai_per_kelas+");?>",
        data: "{id_kelas: id}",
        success: function(data){
            console.log(data)
        }
    })
})








});

















//   $(document).ready(function(){ 
//   // Ketika halaman sudah siap (sudah selesai di load)    
//   // Kita sembunyikan dulu untuk loadingnya    
//   $("#loading").hide();        
//   $("#provinsi").change(function(){ 
//   // Ketika user mengganti atau memilih data provinsi      
//   $("#kota").hide(); 
//   // Sembunyikan dulu combobox kota nya      
//   $("#loading").show(); 
//   // Tampilkan loadingnya          
//   $.ajax({        
//     type: "POST", // Method pengiriman data bisa dengan GET atau POST        
//     url: "<?php echo base_url("index.php/form/listKota"); ?>", // Isi dengan url/path file php yang dituju        
//     data: {id_provinsi : $("#provinsi").val()}, // data yang akan dikirim ke file yang dituju        
//     dataType: "json",        
//     beforeSend: function(e) {          
//         if(e && e.overrideMimeType) {            
//             e.overrideMimeType("application/json;charset=UTF-8");          
//         }        
//   },        
//   success: function(response){ // Ketika proses pengiriman berhasil          
//   $("#loading").hide(); // Sembunyikan loadingnya          
//   // set isi dari combobox kota          
//   // lalu munculkan kembali combobox kotanya          
//   $("#kota").html(response.list_kota).show();        
//   },        
//   error: function (xhr, ajaxOptions, thrownError) { // Ketika ada error          
//   alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError); // Munculkan alert error        
// }     
//  });    
// });  
// });